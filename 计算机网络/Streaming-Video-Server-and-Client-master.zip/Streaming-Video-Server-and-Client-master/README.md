# Streaming-Video-Server-and-Client-
Implemented a Python streaming video server and client that communicate using the Real Time Streaming Protocol (RTSP) and send data using the Real-time Transport Protocol (RTP).
Implemented the RTSP protocol in the server and client, and implemented the RTP packetization in the server.
